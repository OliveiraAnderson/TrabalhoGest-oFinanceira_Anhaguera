﻿namespace AuditA
{
    partial class FormCadastrarLayoutSPEDs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbFormularioCadastrarLayout = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lbFormularioCadastrarLayout);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1102, 644);
            this.panel1.TabIndex = 0;
            // 
            // lbFormularioCadastrarLayout
            // 
            this.lbFormularioCadastrarLayout.AutoSize = true;
            this.lbFormularioCadastrarLayout.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbFormularioCadastrarLayout.ForeColor = System.Drawing.Color.DimGray;
            this.lbFormularioCadastrarLayout.Location = new System.Drawing.Point(3, 9);
            this.lbFormularioCadastrarLayout.Name = "lbFormularioCadastrarLayout";
            this.lbFormularioCadastrarLayout.Size = new System.Drawing.Size(170, 18);
            this.lbFormularioCadastrarLayout.TabIndex = 0;
            this.lbFormularioCadastrarLayout.Text = "Cadastrar Layouts";
            // 
            // FormCadastrarLayoutSPEDs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 644);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormCadastrarLayoutSPEDs";
            this.Text = "Cadastrar Layouts";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Label lbFormularioCadastrarLayout;
    }
}