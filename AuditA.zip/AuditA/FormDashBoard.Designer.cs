﻿namespace AuditA
{
    partial class FormDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelFormDashBoard = new System.Windows.Forms.Panel();
            this.lbTitleDashBoard = new System.Windows.Forms.Label();
            this.PanelFormDashBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelFormDashBoard
            // 
            this.PanelFormDashBoard.BackColor = System.Drawing.Color.White;
            this.PanelFormDashBoard.Controls.Add(this.lbTitleDashBoard);
            this.PanelFormDashBoard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelFormDashBoard.Location = new System.Drawing.Point(0, 0);
            this.PanelFormDashBoard.Name = "PanelFormDashBoard";
            this.PanelFormDashBoard.Size = new System.Drawing.Size(1164, 644);
            this.PanelFormDashBoard.TabIndex = 0;
            // 
            // lbTitleDashBoard
            // 
            this.lbTitleDashBoard.AutoSize = true;
            this.lbTitleDashBoard.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbTitleDashBoard.ForeColor = System.Drawing.Color.DimGray;
            this.lbTitleDashBoard.Location = new System.Drawing.Point(3, 3);
            this.lbTitleDashBoard.Name = "lbTitleDashBoard";
            this.lbTitleDashBoard.Size = new System.Drawing.Size(125, 23);
            this.lbTitleDashBoard.TabIndex = 0;
            this.lbTitleDashBoard.Text = "Dashboard";
            // 
            // FormDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 644);
            this.Controls.Add(this.PanelFormDashBoard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormDashBoard";
            this.Text = "DashBoard";
            this.PanelFormDashBoard.ResumeLayout(false);
            this.PanelFormDashBoard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel PanelFormDashBoard;
        private Label lbTitleDashBoard;
    }
}