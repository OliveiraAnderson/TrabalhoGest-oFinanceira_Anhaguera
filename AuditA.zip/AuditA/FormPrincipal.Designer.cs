﻿namespace AuditA
{
    partial class PanelNavTitle
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PanelNavTitle));
            this.PanelNav = new System.Windows.Forms.Panel();
            this.lbContentMain = new System.Windows.Forms.Label();
            this.iconClose = new FontAwesome.Sharp.IconButton();
            this.iconBar = new FontAwesome.Sharp.IconButton();
            this.panelHome = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.PanelSlideMenu = new System.Windows.Forms.Panel();
            this.iconButton13 = new FontAwesome.Sharp.IconButton();
            this.iconButton12 = new FontAwesome.Sharp.IconButton();
            this.PanelSubMenuCatalago2 = new System.Windows.Forms.Panel();
            this.ibtnSQLSERVER = new FontAwesome.Sharp.IconButton();
            this.ibtnLayoutSPEDs = new FontAwesome.Sharp.IconButton();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.PanelSubMenuCatalago = new System.Windows.Forms.Panel();
            this.ibtnRevista = new FontAwesome.Sharp.IconButton();
            this.ibtnCruzamentos = new FontAwesome.Sharp.IconButton();
            this.ibtnArquivos = new FontAwesome.Sharp.IconButton();
            this.ibtnImportacao = new FontAwesome.Sharp.IconButton();
            this.iconButton11 = new FontAwesome.Sharp.IconButton();
            this.PanelSubMenuCatalago3 = new System.Windows.Forms.Panel();
            this.ibtnCadFiliais = new FontAwesome.Sharp.IconButton();
            this.ibtnCadEmpresas = new FontAwesome.Sharp.IconButton();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.iconDashboard = new FontAwesome.Sharp.IconButton();
            this.PanelSlideMenuImage = new System.Windows.Forms.Panel();
            this.labelUsuario = new System.Windows.Forms.Label();
            this.picBoxImage = new System.Windows.Forms.PictureBox();
            this.PanelContentMain = new System.Windows.Forms.Panel();
            this.PanelNav.SuspendLayout();
            this.panelHome.SuspendLayout();
            this.PanelSlideMenu.SuspendLayout();
            this.PanelSubMenuCatalago2.SuspendLayout();
            this.PanelSubMenuCatalago.SuspendLayout();
            this.PanelSubMenuCatalago3.SuspendLayout();
            this.PanelSlideMenuImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxImage)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelNav
            // 
            this.PanelNav.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PanelNav.Controls.Add(this.lbContentMain);
            this.PanelNav.Controls.Add(this.iconClose);
            this.PanelNav.Controls.Add(this.iconBar);
            this.PanelNav.Controls.Add(this.panelHome);
            this.PanelNav.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelNav.Location = new System.Drawing.Point(0, 0);
            this.PanelNav.Name = "PanelNav";
            this.PanelNav.Size = new System.Drawing.Size(1350, 46);
            this.PanelNav.TabIndex = 0;
            this.PanelNav.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MoveWindowsMouseDown);
            // 
            // lbContentMain
            // 
            this.lbContentMain.AutoSize = true;
            this.lbContentMain.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbContentMain.Font = new System.Drawing.Font("Verdana", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.lbContentMain.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbContentMain.Location = new System.Drawing.Point(248, 11);
            this.lbContentMain.Name = "lbContentMain";
            this.lbContentMain.Size = new System.Drawing.Size(77, 23);
            this.lbContentMain.TabIndex = 3;
            this.lbContentMain.Text = "label1";
            // 
            // iconClose
            // 
            this.iconClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconClose.FlatAppearance.BorderSize = 0;
            this.iconClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconClose.IconChar = FontAwesome.Sharp.IconChar.PowerOff;
            this.iconClose.IconColor = System.Drawing.Color.Gainsboro;
            this.iconClose.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconClose.IconSize = 30;
            this.iconClose.Location = new System.Drawing.Point(1313, 0);
            this.iconClose.Name = "iconClose";
            this.iconClose.Size = new System.Drawing.Size(37, 46);
            this.iconClose.TabIndex = 2;
            this.iconClose.UseVisualStyleBackColor = true;
            this.iconClose.Click += new System.EventHandler(this.iconClose_Click);
            // 
            // iconBar
            // 
            this.iconBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.iconBar.FlatAppearance.BorderSize = 0;
            this.iconBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBar.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconBar.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.iconBar.IconColor = System.Drawing.Color.Gainsboro;
            this.iconBar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBar.IconSize = 30;
            this.iconBar.Location = new System.Drawing.Point(170, 0);
            this.iconBar.Name = "iconBar";
            this.iconBar.Size = new System.Drawing.Size(37, 46);
            this.iconBar.TabIndex = 1;
            this.iconBar.UseVisualStyleBackColor = true;
            this.iconBar.Click += new System.EventHandler(this.iconBar_Click);
            // 
            // panelHome
            // 
            this.panelHome.Controls.Add(this.labelTitle);
            this.panelHome.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelHome.Location = new System.Drawing.Point(0, 0);
            this.panelHome.Name = "panelHome";
            this.panelHome.Size = new System.Drawing.Size(170, 46);
            this.panelHome.TabIndex = 0;
            this.panelHome.Paint += new System.Windows.Forms.PaintEventHandler(this.panelHome_Paint);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelTitle.ForeColor = System.Drawing.Color.Gainsboro;
            this.labelTitle.Location = new System.Drawing.Point(-1, 8);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(169, 18);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Controladoria TCC";
            this.labelTitle.Click += new System.EventHandler(this.labelTitle_Click);
            // 
            // PanelSlideMenu
            // 
            this.PanelSlideMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PanelSlideMenu.Controls.Add(this.iconButton13);
            this.PanelSlideMenu.Controls.Add(this.iconButton12);
            this.PanelSlideMenu.Controls.Add(this.PanelSubMenuCatalago2);
            this.PanelSlideMenu.Controls.Add(this.iconButton2);
            this.PanelSlideMenu.Controls.Add(this.PanelSubMenuCatalago);
            this.PanelSlideMenu.Controls.Add(this.iconButton11);
            this.PanelSlideMenu.Controls.Add(this.PanelSubMenuCatalago3);
            this.PanelSlideMenu.Controls.Add(this.iconButton1);
            this.PanelSlideMenu.Controls.Add(this.iconDashboard);
            this.PanelSlideMenu.Controls.Add(this.PanelSlideMenuImage);
            this.PanelSlideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelSlideMenu.Location = new System.Drawing.Point(0, 46);
            this.PanelSlideMenu.Name = "PanelSlideMenu";
            this.PanelSlideMenu.Size = new System.Drawing.Size(220, 683);
            this.PanelSlideMenu.TabIndex = 1;
            // 
            // iconButton13
            // 
            this.iconButton13.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton13.FlatAppearance.BorderSize = 0;
            this.iconButton13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconButton13.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconButton13.IconChar = FontAwesome.Sharp.IconChar.Skype;
            this.iconButton13.IconColor = System.Drawing.Color.White;
            this.iconButton13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton13.IconSize = 32;
            this.iconButton13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton13.Location = new System.Drawing.Point(0, 618);
            this.iconButton13.Name = "iconButton13";
            this.iconButton13.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconButton13.Size = new System.Drawing.Size(220, 39);
            this.iconButton13.TabIndex = 44;
            this.iconButton13.Text = "           Treinamento";
            this.iconButton13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton13.UseVisualStyleBackColor = true;
            this.iconButton13.Click += new System.EventHandler(this.iconButton13_Click);
            // 
            // iconButton12
            // 
            this.iconButton12.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton12.FlatAppearance.BorderSize = 0;
            this.iconButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconButton12.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconButton12.IconChar = FontAwesome.Sharp.IconChar.Calendar;
            this.iconButton12.IconColor = System.Drawing.Color.White;
            this.iconButton12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton12.IconSize = 32;
            this.iconButton12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton12.Location = new System.Drawing.Point(0, 579);
            this.iconButton12.Name = "iconButton12";
            this.iconButton12.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconButton12.Size = new System.Drawing.Size(220, 39);
            this.iconButton12.TabIndex = 43;
            this.iconButton12.Text = "           Agenda";
            this.iconButton12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton12.UseVisualStyleBackColor = true;
            this.iconButton12.Click += new System.EventHandler(this.iconButton12_Click);
            // 
            // PanelSubMenuCatalago2
            // 
            this.PanelSubMenuCatalago2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.PanelSubMenuCatalago2.Controls.Add(this.ibtnSQLSERVER);
            this.PanelSubMenuCatalago2.Controls.Add(this.ibtnLayoutSPEDs);
            this.PanelSubMenuCatalago2.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelSubMenuCatalago2.Location = new System.Drawing.Point(0, 519);
            this.PanelSubMenuCatalago2.Name = "PanelSubMenuCatalago2";
            this.PanelSubMenuCatalago2.Size = new System.Drawing.Size(220, 60);
            this.PanelSubMenuCatalago2.TabIndex = 42;
            // 
            // ibtnSQLSERVER
            // 
            this.ibtnSQLSERVER.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnSQLSERVER.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnSQLSERVER.FlatAppearance.BorderSize = 0;
            this.ibtnSQLSERVER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnSQLSERVER.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnSQLSERVER.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnSQLSERVER.IconChar = FontAwesome.Sharp.IconChar.Database;
            this.ibtnSQLSERVER.IconColor = System.Drawing.Color.White;
            this.ibtnSQLSERVER.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnSQLSERVER.IconSize = 28;
            this.ibtnSQLSERVER.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnSQLSERVER.Location = new System.Drawing.Point(0, 34);
            this.ibtnSQLSERVER.Name = "ibtnSQLSERVER";
            this.ibtnSQLSERVER.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnSQLSERVER.Size = new System.Drawing.Size(220, 26);
            this.ibtnSQLSERVER.TabIndex = 27;
            this.ibtnSQLSERVER.Text = "           SQL Server";
            this.ibtnSQLSERVER.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnSQLSERVER.UseVisualStyleBackColor = false;
            this.ibtnSQLSERVER.Click += new System.EventHandler(this.ibtnSQLSERVER_Click);
            // 
            // ibtnLayoutSPEDs
            // 
            this.ibtnLayoutSPEDs.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnLayoutSPEDs.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnLayoutSPEDs.FlatAppearance.BorderSize = 0;
            this.ibtnLayoutSPEDs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnLayoutSPEDs.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnLayoutSPEDs.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnLayoutSPEDs.IconChar = FontAwesome.Sharp.IconChar.Folder;
            this.ibtnLayoutSPEDs.IconColor = System.Drawing.Color.White;
            this.ibtnLayoutSPEDs.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnLayoutSPEDs.IconSize = 28;
            this.ibtnLayoutSPEDs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnLayoutSPEDs.Location = new System.Drawing.Point(0, 0);
            this.ibtnLayoutSPEDs.Name = "ibtnLayoutSPEDs";
            this.ibtnLayoutSPEDs.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnLayoutSPEDs.Size = new System.Drawing.Size(220, 34);
            this.ibtnLayoutSPEDs.TabIndex = 26;
            this.ibtnLayoutSPEDs.Text = "           Leiautes";
            this.ibtnLayoutSPEDs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnLayoutSPEDs.UseVisualStyleBackColor = false;
            this.ibtnLayoutSPEDs.Click += new System.EventHandler(this.ibtnLayoutSPEDs_Click);
            // 
            // iconButton2
            // 
            this.iconButton2.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton2.FlatAppearance.BorderSize = 0;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconButton2.ForeColor = System.Drawing.Color.Transparent;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.Dev;
            this.iconButton2.IconColor = System.Drawing.Color.White;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 32;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(0, 471);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconButton2.Size = new System.Drawing.Size(220, 48);
            this.iconButton2.TabIndex = 41;
            this.iconButton2.Text = "           Developer";
            this.iconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.UseVisualStyleBackColor = true;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // PanelSubMenuCatalago
            // 
            this.PanelSubMenuCatalago.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.PanelSubMenuCatalago.Controls.Add(this.ibtnRevista);
            this.PanelSubMenuCatalago.Controls.Add(this.ibtnCruzamentos);
            this.PanelSubMenuCatalago.Controls.Add(this.ibtnArquivos);
            this.PanelSubMenuCatalago.Controls.Add(this.ibtnImportacao);
            this.PanelSubMenuCatalago.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelSubMenuCatalago.Location = new System.Drawing.Point(0, 332);
            this.PanelSubMenuCatalago.Name = "PanelSubMenuCatalago";
            this.PanelSubMenuCatalago.Size = new System.Drawing.Size(220, 139);
            this.PanelSubMenuCatalago.TabIndex = 40;
            // 
            // ibtnRevista
            // 
            this.ibtnRevista.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnRevista.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnRevista.FlatAppearance.BorderSize = 0;
            this.ibtnRevista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnRevista.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnRevista.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnRevista.IconChar = FontAwesome.Sharp.IconChar.FilePdf;
            this.ibtnRevista.IconColor = System.Drawing.Color.White;
            this.ibtnRevista.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnRevista.IconSize = 28;
            this.ibtnRevista.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnRevista.Location = new System.Drawing.Point(0, 102);
            this.ibtnRevista.Name = "ibtnRevista";
            this.ibtnRevista.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnRevista.Size = new System.Drawing.Size(220, 36);
            this.ibtnRevista.TabIndex = 15;
            this.ibtnRevista.Text = "           Revista";
            this.ibtnRevista.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnRevista.UseVisualStyleBackColor = false;
            this.ibtnRevista.Click += new System.EventHandler(this.ibtnRevista_Click);
            // 
            // ibtnCruzamentos
            // 
            this.ibtnCruzamentos.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnCruzamentos.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnCruzamentos.FlatAppearance.BorderSize = 0;
            this.ibtnCruzamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnCruzamentos.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnCruzamentos.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnCruzamentos.IconChar = FontAwesome.Sharp.IconChar.Audible;
            this.ibtnCruzamentos.IconColor = System.Drawing.Color.White;
            this.ibtnCruzamentos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCruzamentos.IconSize = 28;
            this.ibtnCruzamentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCruzamentos.Location = new System.Drawing.Point(0, 68);
            this.ibtnCruzamentos.Name = "ibtnCruzamentos";
            this.ibtnCruzamentos.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnCruzamentos.Size = new System.Drawing.Size(220, 34);
            this.ibtnCruzamentos.TabIndex = 14;
            this.ibtnCruzamentos.Text = "           Cruzamentos";
            this.ibtnCruzamentos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCruzamentos.UseVisualStyleBackColor = false;
            this.ibtnCruzamentos.Click += new System.EventHandler(this.ibtnCruzamentos_Click);
            // 
            // ibtnArquivos
            // 
            this.ibtnArquivos.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnArquivos.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnArquivos.FlatAppearance.BorderSize = 0;
            this.ibtnArquivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnArquivos.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnArquivos.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnArquivos.IconChar = FontAwesome.Sharp.IconChar.FileImport;
            this.ibtnArquivos.IconColor = System.Drawing.Color.White;
            this.ibtnArquivos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnArquivos.IconSize = 28;
            this.ibtnArquivos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnArquivos.Location = new System.Drawing.Point(0, 34);
            this.ibtnArquivos.Name = "ibtnArquivos";
            this.ibtnArquivos.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnArquivos.Size = new System.Drawing.Size(220, 34);
            this.ibtnArquivos.TabIndex = 13;
            this.ibtnArquivos.Text = "           Arquivos";
            this.ibtnArquivos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnArquivos.UseVisualStyleBackColor = false;
            this.ibtnArquivos.Click += new System.EventHandler(this.ibtnArquivos_Click);
            // 
            // ibtnImportacao
            // 
            this.ibtnImportacao.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnImportacao.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnImportacao.FlatAppearance.BorderSize = 0;
            this.ibtnImportacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnImportacao.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnImportacao.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnImportacao.IconChar = FontAwesome.Sharp.IconChar.FileUpload;
            this.ibtnImportacao.IconColor = System.Drawing.Color.White;
            this.ibtnImportacao.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnImportacao.IconSize = 28;
            this.ibtnImportacao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnImportacao.Location = new System.Drawing.Point(0, 0);
            this.ibtnImportacao.Name = "ibtnImportacao";
            this.ibtnImportacao.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnImportacao.Size = new System.Drawing.Size(220, 34);
            this.ibtnImportacao.TabIndex = 12;
            this.ibtnImportacao.Text = "           Importação";
            this.ibtnImportacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnImportacao.UseVisualStyleBackColor = false;
            this.ibtnImportacao.Click += new System.EventHandler(this.ibtnImportacao_Click);
            // 
            // iconButton11
            // 
            this.iconButton11.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton11.FlatAppearance.BorderSize = 0;
            this.iconButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconButton11.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconButton11.IconChar = FontAwesome.Sharp.IconChar.Industry;
            this.iconButton11.IconColor = System.Drawing.Color.White;
            this.iconButton11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton11.IconSize = 32;
            this.iconButton11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton11.Location = new System.Drawing.Point(0, 283);
            this.iconButton11.Name = "iconButton11";
            this.iconButton11.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconButton11.Size = new System.Drawing.Size(220, 49);
            this.iconButton11.TabIndex = 39;
            this.iconButton11.Text = "           Compliance";
            this.iconButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton11.UseVisualStyleBackColor = true;
            this.iconButton11.Click += new System.EventHandler(this.iconButton11_Click);
            // 
            // PanelSubMenuCatalago3
            // 
            this.PanelSubMenuCatalago3.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.PanelSubMenuCatalago3.Controls.Add(this.ibtnCadFiliais);
            this.PanelSubMenuCatalago3.Controls.Add(this.ibtnCadEmpresas);
            this.PanelSubMenuCatalago3.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelSubMenuCatalago3.Location = new System.Drawing.Point(0, 228);
            this.PanelSubMenuCatalago3.Name = "PanelSubMenuCatalago3";
            this.PanelSubMenuCatalago3.Size = new System.Drawing.Size(220, 55);
            this.PanelSubMenuCatalago3.TabIndex = 38;
            // 
            // ibtnCadFiliais
            // 
            this.ibtnCadFiliais.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnCadFiliais.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnCadFiliais.FlatAppearance.BorderSize = 0;
            this.ibtnCadFiliais.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnCadFiliais.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnCadFiliais.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnCadFiliais.IconChar = FontAwesome.Sharp.IconChar.Houzz;
            this.ibtnCadFiliais.IconColor = System.Drawing.Color.White;
            this.ibtnCadFiliais.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCadFiliais.IconSize = 28;
            this.ibtnCadFiliais.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCadFiliais.Location = new System.Drawing.Point(0, 26);
            this.ibtnCadFiliais.Name = "ibtnCadFiliais";
            this.ibtnCadFiliais.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnCadFiliais.Size = new System.Drawing.Size(220, 26);
            this.ibtnCadFiliais.TabIndex = 30;
            this.ibtnCadFiliais.Text = "          Matriz e Filial";
            this.ibtnCadFiliais.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCadFiliais.UseVisualStyleBackColor = false;
            this.ibtnCadFiliais.Click += new System.EventHandler(this.ibtnCadFiliais_Click);
            // 
            // ibtnCadEmpresas
            // 
            this.ibtnCadEmpresas.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ibtnCadEmpresas.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnCadEmpresas.FlatAppearance.BorderSize = 0;
            this.ibtnCadEmpresas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnCadEmpresas.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ibtnCadEmpresas.ForeColor = System.Drawing.Color.Transparent;
            this.ibtnCadEmpresas.IconChar = FontAwesome.Sharp.IconChar.Industry;
            this.ibtnCadEmpresas.IconColor = System.Drawing.Color.White;
            this.ibtnCadEmpresas.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCadEmpresas.IconSize = 28;
            this.ibtnCadEmpresas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCadEmpresas.Location = new System.Drawing.Point(0, 0);
            this.ibtnCadEmpresas.Name = "ibtnCadEmpresas";
            this.ibtnCadEmpresas.Padding = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.ibtnCadEmpresas.Size = new System.Drawing.Size(220, 26);
            this.ibtnCadEmpresas.TabIndex = 29;
            this.ibtnCadEmpresas.Text = "          Matriz";
            this.ibtnCadEmpresas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCadEmpresas.UseVisualStyleBackColor = false;
            this.ibtnCadEmpresas.Click += new System.EventHandler(this.ibtnCadEmpresas_Click);
            // 
            // iconButton1
            // 
            this.iconButton1.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconButton1.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.Server;
            this.iconButton1.IconColor = System.Drawing.Color.White;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 32;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(0, 181);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconButton1.Size = new System.Drawing.Size(220, 47);
            this.iconButton1.TabIndex = 4;
            this.iconButton1.Text = "             Empresas";
            this.iconButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // iconDashboard
            // 
            this.iconDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconDashboard.FlatAppearance.BorderSize = 0;
            this.iconDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconDashboard.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iconDashboard.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconDashboard.IconChar = FontAwesome.Sharp.IconChar.Laptop;
            this.iconDashboard.IconColor = System.Drawing.Color.White;
            this.iconDashboard.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconDashboard.IconSize = 32;
            this.iconDashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconDashboard.Location = new System.Drawing.Point(0, 134);
            this.iconDashboard.Name = "iconDashboard";
            this.iconDashboard.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.iconDashboard.Size = new System.Drawing.Size(220, 47);
            this.iconDashboard.TabIndex = 3;
            this.iconDashboard.Text = "           Dashboard";
            this.iconDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconDashboard.UseVisualStyleBackColor = true;
            this.iconDashboard.Click += new System.EventHandler(this.iconDashboard_Click);
            // 
            // PanelSlideMenuImage
            // 
            this.PanelSlideMenuImage.Controls.Add(this.labelUsuario);
            this.PanelSlideMenuImage.Controls.Add(this.picBoxImage);
            this.PanelSlideMenuImage.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelSlideMenuImage.Location = new System.Drawing.Point(0, 0);
            this.PanelSlideMenuImage.Name = "PanelSlideMenuImage";
            this.PanelSlideMenuImage.Size = new System.Drawing.Size(220, 134);
            this.PanelSlideMenuImage.TabIndex = 2;
            // 
            // labelUsuario
            // 
            this.labelUsuario.AutoSize = true;
            this.labelUsuario.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelUsuario.ForeColor = System.Drawing.Color.Gainsboro;
            this.labelUsuario.Location = new System.Drawing.Point(7, 107);
            this.labelUsuario.Name = "labelUsuario";
            this.labelUsuario.Size = new System.Drawing.Size(126, 14);
            this.labelUsuario.TabIndex = 3;
            this.labelUsuario.Text = "Anderson Oliveira";
            // 
            // picBoxImage
            // 
            this.picBoxImage.Image = ((System.Drawing.Image)(resources.GetObject("picBoxImage.Image")));
            this.picBoxImage.Location = new System.Drawing.Point(12, 6);
            this.picBoxImage.Name = "picBoxImage";
            this.picBoxImage.Size = new System.Drawing.Size(115, 93);
            this.picBoxImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxImage.TabIndex = 2;
            this.picBoxImage.TabStop = false;
            // 
            // PanelContentMain
            // 
            this.PanelContentMain.BackColor = System.Drawing.Color.White;
            this.PanelContentMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelContentMain.Location = new System.Drawing.Point(220, 46);
            this.PanelContentMain.Name = "PanelContentMain";
            this.PanelContentMain.Size = new System.Drawing.Size(1130, 683);
            this.PanelContentMain.TabIndex = 2;
            // 
            // PanelNavTitle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.PanelContentMain);
            this.Controls.Add(this.PanelSlideMenu);
            this.Controls.Add(this.PanelNav);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "PanelNavTitle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Principal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PanelNavTitle_FormClosing);
            this.Load += new System.EventHandler(this.PanelNavTitle_Load);
            this.PanelNav.ResumeLayout(false);
            this.PanelNav.PerformLayout();
            this.panelHome.ResumeLayout(false);
            this.panelHome.PerformLayout();
            this.PanelSlideMenu.ResumeLayout(false);
            this.PanelSubMenuCatalago2.ResumeLayout(false);
            this.PanelSubMenuCatalago.ResumeLayout(false);
            this.PanelSubMenuCatalago3.ResumeLayout(false);
            this.PanelSlideMenuImage.ResumeLayout(false);
            this.PanelSlideMenuImage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel PanelNav;
        private Panel panelHome;
        private Label labelTitle;
        private FontAwesome.Sharp.IconButton iconBar;
        private FontAwesome.Sharp.IconButton iconClose;
        private Panel PanelSlideMenu;
        private Panel PanelSlideMenuImage;
        private PictureBox picBoxImage;
        private FontAwesome.Sharp.IconButton iconDashboard;
        private FontAwesome.Sharp.IconButton iconButton1;
        private Panel PanelContentMain;
        private Label labelUsuario;
        private Panel PanelSubMenuCatalago3;
        private Panel PanelSubMenuCatalago;
        private FontAwesome.Sharp.IconButton ibtnRevista;
        private FontAwesome.Sharp.IconButton ibtnCruzamentos;
        private FontAwesome.Sharp.IconButton ibtnArquivos;
        private FontAwesome.Sharp.IconButton ibtnImportacao;
        private FontAwesome.Sharp.IconButton iconButton11;
        private FontAwesome.Sharp.IconButton ibtnCadEmpresas;
        private FontAwesome.Sharp.IconButton iconButton13;
        private FontAwesome.Sharp.IconButton iconButton12;
        private Panel PanelSubMenuCatalago2;
        private FontAwesome.Sharp.IconButton ibtnSQLSERVER;
        private FontAwesome.Sharp.IconButton ibtnLayoutSPEDs;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton ibtnCadFiliais;
        private Label lbContentMain;
    }
}