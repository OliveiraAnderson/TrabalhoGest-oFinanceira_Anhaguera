using FontAwesome.Sharp;
using System.Runtime.InteropServices;
using Tulpep.NotificationWindow;

namespace AuditA
{
    public partial class PanelNavTitle : Form
    {
        //Fields
        private IconButton currentBtn;
        private Panel leftBorderBtn;
        private Form _objForm;

        private const int widthSlide = 170;
        private const int widthSlideIcon = 45;

        [DllImport("user32.dll", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
   
        [DllImport("user32.DLL", EntryPoint = "SendMensagem")]
        private extern static void SendMenssage(System.IntPtr hWnd, int wMsg, int wParam, int lParam );



        //Constructor
        public PanelNavTitle()
        {
            InitializeComponent();
            InitializeSetting();
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7, 60);
            PanelSlideMenu.Controls.Add(leftBorderBtn);

            //Form
            this.Text = string.Empty;
            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;

           


        }

        //Structs Color RGB
        private struct RGBColors 
        {
            //RGB Color 
            //public static Color color1 = Color.FromArgb(172, 126, 241);
            //public static Color color2 = Color.FromArgb(249, 118, 176);
            //public static Color color3 = Color.FromArgb(253, 138, 114);
            //public static Color color4 = Color.FromArgb(95, 77, 221);
            //public static Color color5 = Color.FromArgb(249, 88, 155);
            //public static Color color6 = Color.FromArgb(24, 161, 251);
            //public static Color color7 = Color.FromArgb(172, 126, 241);
            //public static Color color8 = Color.FromArgb(249, 118, 176);
            public static Color color9 = Color.FromArgb(253, 138, 114);
            public static Color color10 = Color.FromArgb(95, 77, 221);
            //public static Color color11 = Color.FromArgb(249, 88, 155);
            //public static Color color12 = Color.FromArgb(24, 161, 251);
            //public static Color color13 = Color.FromArgb(172, 126, 241);
            //public static Color color14 = Color.FromArgb(249, 118, 176);
            //public static Color color15 = Color.FromArgb(253, 138, 114);
            
        }



        //Create Methods 
        private void ActiveButton(object senderBtn, Color color)
        {

            if (senderBtn!=null)
            {
                //Call Methods
                DisableButton();


                //Button
                currentBtn = (IconButton)senderBtn;
                currentBtn.BackColor = Color.FromArgb(37,38,81);
                currentBtn.ForeColor = color;
                currentBtn.TextAlign = ContentAlignment.MiddleCenter;
                currentBtn.IconColor = color;
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentBtn.ImageAlign = ContentAlignment.MiddleRight;

                //Left Border Button
                leftBorderBtn.BackColor = color;
                leftBorderBtn.Location = new Point(0, currentBtn.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();

            }
        }



        private void DisableButton()
        {
            if (currentBtn!=null)
            {
                
                currentBtn.BackColor = Color.FromArgb(31,30,68);
                currentBtn.ForeColor = Color.Gainsboro;
                currentBtn.TextAlign = ContentAlignment.MiddleLeft;
                currentBtn.IconColor = Color.Gainsboro;
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }

        private void openChildForm(Form childForm)
        {
            if (_objForm != null)
            {
                //open only form
                _objForm.Close();
            }
            _objForm = childForm;
            _objForm.TopLevel = false;
            _objForm.FormBorderStyle = FormBorderStyle.None;
            _objForm.Dock = DockStyle.Fill;
            PanelContentMain.Controls.Add(_objForm);
            PanelContentMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lbContentMain.Text = childForm.Text;

        }

        public void InitializeSetting()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            HideSubMenus();
            HideSubMenusDEVW();
            HideSubMenusEmpresas();

        }

        private void HideSubMenus()
        {
            PanelSubMenuCatalago.Visible = false;

        }

        private void HideSubMenusDEVW()
        {
            PanelSubMenuCatalago2.Visible = false;

        }

        private void HideSubMenusEmpresas()
        {
            PanelSubMenuCatalago3.Visible = false;

        }



        private void MoveWindowsMouseDown()
        {
            ReleaseCapture();
            SendMenssage(this.Handle, 0x112, 0xf012, 0);
        }

        public void ShowSubMenu(Panel subMenu)
        {
            if (subMenu.Visible==false)
            {
                HideSubMenus();
                subMenu.Visible=true;
            }
            else
            {
                subMenu.Visible=false;
            }
        }


        public void ShowSubMenuDEVW(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                HideSubMenusDEVW();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }

        public void ShowSubMenuEmpresas(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                HideSubMenusEmpresas();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }


        private void iconButton1_Click(object sender, EventArgs e)
        {
           
            ShowSubMenuEmpresas(PanelSubMenuCatalago3);           

        }

        private void MoveWindowsMouseDown(object sender, MouseEventArgs e)
        {

        }

        private void iconClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconDashboard_Click(object sender, EventArgs e)
        {
            //ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormDashBoard());

        }

        private void iconBar_Click(object sender, EventArgs e)
        {
            


            if (_objForm != null)
            {
                //open only form
                _objForm.Close();
            }
            _objForm = new FormHome();
            _objForm.TopLevel = false;
            _objForm.FormBorderStyle = FormBorderStyle.None;
            _objForm.Dock = DockStyle.Fill;
            PanelContentMain.Controls.Add(_objForm);
            PanelContentMain.Tag = _objForm;
            _objForm.BringToFront();
            _objForm.Show();
            lbContentMain.Text = _objForm.Text;

            if (PanelSlideMenu.Width !=widthSlideIcon)
            {
                PanelSlideMenu.Width =widthSlideIcon;
                HideSubMenus();
                HideSubMenusDEVW();
                HideSubMenusEmpresas();
                PanelSlideMenuImage.Visible = false;

               

            }
            else
            {
                PanelSlideMenu.Width = widthSlide;
                PanelSlideMenuImage.Visible = true;

            }

            Reset();
           
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            
        }

        private void iconButton10_Click(object sender, EventArgs e)
        {

        }

        private void iconButton8_Click(object sender, EventArgs e)
        {
            
        }

        private void iconButton11_Click(object sender, EventArgs e)
        {
            ShowSubMenu(PanelSubMenuCatalago);
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
         
            ShowSubMenuDEVW(PanelSubMenuCatalago2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
             

        }

        private void iconButton9_Click(object sender, EventArgs e)
        {
             
        }

        private void ibtnCadEmpresas_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormEmpresas());
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
    


        }

        private void ibtnCadFiliais_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormFiliais());
        }

        private void labelTitle_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            DisableButton();
            leftBorderBtn.Visible = false;
        }

        private void panelHome_Paint(object sender, PaintEventArgs e)
        {
            _objForm?.Close();

            _objForm = new FormHome
            {
                TopLevel = false,
                FormBorderStyle = FormBorderStyle.None,
                Dock = DockStyle.Fill
            };

            PanelContentMain.Controls.Add(_objForm);
            _objForm.Show();
            lbContentMain.Text = _objForm.Text;


        }

        private void ibtnImportacao_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormImportacaoArquivos());
        }

        private void ibtnArquivos_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormArquivosImportados());
        }

        private void ibtnLayoutSPEDs_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color10);
            openChildForm(new FormCadastrarLayoutSPEDs());
        }

        private void ibtnSQLSERVER_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color10);
            openChildForm(new FormModuloSQLSERVER());

        }

        private void ibtnCruzamentos_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormCruzamentosAutomaticos());
        }

        private void ibtnRevista_Click(object sender, EventArgs e)
        {
            ActiveButton(sender, RGBColors.color9);
            openChildForm(new FormRevista());
        }

        private void iconButton12_Click(object sender, EventArgs e)
        {
            
        }

        private void iconButton13_Click(object sender, EventArgs e)
        {
           
        }

        private void PanelNavTitle_Load(object sender, EventArgs e)
        {

        }

        private void PanelNavTitle_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Deseja sair da aplica��o?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}