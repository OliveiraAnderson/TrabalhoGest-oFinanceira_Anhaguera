﻿namespace AuditA
{
    partial class FormArquivosImportados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelFormArquivosImportados = new System.Windows.Forms.Panel();
            this.panelListaArquivosImportados = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panelFormArquivosImportadosDados = new System.Windows.Forms.Panel();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnFiltrarArquivos = new System.Windows.Forms.Button();
            this.cbxTipoArquivos = new System.Windows.Forms.ComboBox();
            this.lbTipoArquivo = new System.Windows.Forms.Label();
            this.txAnoFinal = new System.Windows.Forms.TextBox();
            this.lbPerFinal = new System.Windows.Forms.Label();
            this.lbPerInicial = new System.Windows.Forms.Label();
            this.txAnoInicial = new System.Windows.Forms.TextBox();
            this.lbArquivosImportados = new System.Windows.Forms.Label();
            this.panelFormArquivosImportados.SuspendLayout();
            this.panelListaArquivosImportados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelFormArquivosImportadosDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelFormArquivosImportados
            // 
            this.panelFormArquivosImportados.BackColor = System.Drawing.Color.White;
            this.panelFormArquivosImportados.Controls.Add(this.panelListaArquivosImportados);
            this.panelFormArquivosImportados.Controls.Add(this.panelFormArquivosImportadosDados);
            this.panelFormArquivosImportados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFormArquivosImportados.Location = new System.Drawing.Point(0, 0);
            this.panelFormArquivosImportados.Name = "panelFormArquivosImportados";
            this.panelFormArquivosImportados.Size = new System.Drawing.Size(1164, 644);
            this.panelFormArquivosImportados.TabIndex = 0;
            // 
            // panelListaArquivosImportados
            // 
            this.panelListaArquivosImportados.Controls.Add(this.dataGridView1);
            this.panelListaArquivosImportados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelListaArquivosImportados.Location = new System.Drawing.Point(0, 167);
            this.panelListaArquivosImportados.Name = "panelListaArquivosImportados";
            this.panelListaArquivosImportados.Size = new System.Drawing.Size(1164, 477);
            this.panelListaArquivosImportados.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(1164, 477);
            this.dataGridView1.TabIndex = 0;
            // 
            // panelFormArquivosImportadosDados
            // 
            this.panelFormArquivosImportadosDados.Controls.Add(this.btnExcluir);
            this.panelFormArquivosImportadosDados.Controls.Add(this.btnFiltrarArquivos);
            this.panelFormArquivosImportadosDados.Controls.Add(this.cbxTipoArquivos);
            this.panelFormArquivosImportadosDados.Controls.Add(this.lbTipoArquivo);
            this.panelFormArquivosImportadosDados.Controls.Add(this.txAnoFinal);
            this.panelFormArquivosImportadosDados.Controls.Add(this.lbPerFinal);
            this.panelFormArquivosImportadosDados.Controls.Add(this.lbPerInicial);
            this.panelFormArquivosImportadosDados.Controls.Add(this.txAnoInicial);
            this.panelFormArquivosImportadosDados.Controls.Add(this.lbArquivosImportados);
            this.panelFormArquivosImportadosDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFormArquivosImportadosDados.Location = new System.Drawing.Point(0, 0);
            this.panelFormArquivosImportadosDados.Name = "panelFormArquivosImportadosDados";
            this.panelFormArquivosImportadosDados.Size = new System.Drawing.Size(1164, 167);
            this.panelFormArquivosImportadosDados.TabIndex = 0;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.Moccasin;
            this.btnExcluir.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExcluir.Location = new System.Drawing.Point(938, 96);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(129, 31);
            this.btnExcluir.TabIndex = 22;
            this.btnExcluir.Text = "&Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            // 
            // btnFiltrarArquivos
            // 
            this.btnFiltrarArquivos.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnFiltrarArquivos.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnFiltrarArquivos.FlatAppearance.BorderSize = 0;
            this.btnFiltrarArquivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFiltrarArquivos.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFiltrarArquivos.Location = new System.Drawing.Point(803, 96);
            this.btnFiltrarArquivos.Name = "btnFiltrarArquivos";
            this.btnFiltrarArquivos.Size = new System.Drawing.Size(129, 31);
            this.btnFiltrarArquivos.TabIndex = 20;
            this.btnFiltrarArquivos.Text = "&Filtrar";
            this.btnFiltrarArquivos.UseVisualStyleBackColor = false;
            this.btnFiltrarArquivos.Click += new System.EventHandler(this.btnFiltrarArquivos_Click);
            // 
            // cbxTipoArquivos
            // 
            this.cbxTipoArquivos.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbxTipoArquivos.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbxTipoArquivos.ForeColor = System.Drawing.Color.DimGray;
            this.cbxTipoArquivos.FormattingEnabled = true;
            this.cbxTipoArquivos.Items.AddRange(new object[] {
            "<<TODOS>>",
            "SPED ICMS/IPI",
            "SPED CONTÁBIL",
            "SPED CONTRINUIÇÕES",
            "SPED ECF",
            "DCTFs",
            "G.I.As",
            "DARFs",
            "FOLHA DE PAGAMENTO"});
            this.cbxTipoArquivos.Location = new System.Drawing.Point(390, 96);
            this.cbxTipoArquivos.Name = "cbxTipoArquivos";
            this.cbxTipoArquivos.Size = new System.Drawing.Size(407, 31);
            this.cbxTipoArquivos.TabIndex = 6;
            // 
            // lbTipoArquivo
            // 
            this.lbTipoArquivo.AutoSize = true;
            this.lbTipoArquivo.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbTipoArquivo.ForeColor = System.Drawing.Color.DimGray;
            this.lbTipoArquivo.Location = new System.Drawing.Point(390, 59);
            this.lbTipoArquivo.Name = "lbTipoArquivo";
            this.lbTipoArquivo.Size = new System.Drawing.Size(151, 18);
            this.lbTipoArquivo.TabIndex = 5;
            this.lbTipoArquivo.Text = "Tipo do Arquivo:";
            // 
            // txAnoFinal
            // 
            this.txAnoFinal.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txAnoFinal.Location = new System.Drawing.Point(224, 96);
            this.txAnoFinal.Name = "txAnoFinal";
            this.txAnoFinal.Size = new System.Drawing.Size(139, 31);
            this.txAnoFinal.TabIndex = 4;
            // 
            // lbPerFinal
            // 
            this.lbPerFinal.AutoSize = true;
            this.lbPerFinal.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbPerFinal.ForeColor = System.Drawing.Color.DimGray;
            this.lbPerFinal.Location = new System.Drawing.Point(224, 59);
            this.lbPerFinal.Name = "lbPerFinal";
            this.lbPerFinal.Size = new System.Drawing.Size(127, 18);
            this.lbPerFinal.TabIndex = 3;
            this.lbPerFinal.Text = "Período Final:";
            // 
            // lbPerInicial
            // 
            this.lbPerInicial.AutoSize = true;
            this.lbPerInicial.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbPerInicial.ForeColor = System.Drawing.Color.DimGray;
            this.lbPerInicial.Location = new System.Drawing.Point(31, 59);
            this.lbPerInicial.Name = "lbPerInicial";
            this.lbPerInicial.Size = new System.Drawing.Size(138, 18);
            this.lbPerInicial.TabIndex = 2;
            this.lbPerInicial.Text = "Período Inicial:";
            // 
            // txAnoInicial
            // 
            this.txAnoInicial.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txAnoInicial.Location = new System.Drawing.Point(31, 96);
            this.txAnoInicial.Name = "txAnoInicial";
            this.txAnoInicial.Size = new System.Drawing.Size(139, 31);
            this.txAnoInicial.TabIndex = 1;
            // 
            // lbArquivosImportados
            // 
            this.lbArquivosImportados.AutoSize = true;
            this.lbArquivosImportados.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbArquivosImportados.ForeColor = System.Drawing.Color.DimGray;
            this.lbArquivosImportados.Location = new System.Drawing.Point(12, 9);
            this.lbArquivosImportados.Name = "lbArquivosImportados";
            this.lbArquivosImportados.Size = new System.Drawing.Size(235, 23);
            this.lbArquivosImportados.TabIndex = 0;
            this.lbArquivosImportados.Text = "Arquivos Importados";
            // 
            // FormArquivosImportados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 644);
            this.Controls.Add(this.panelFormArquivosImportados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormArquivosImportados";
            this.Text = "Arquivos Importados";
            this.panelFormArquivosImportados.ResumeLayout(false);
            this.panelListaArquivosImportados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelFormArquivosImportadosDados.ResumeLayout(false);
            this.panelFormArquivosImportadosDados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panelFormArquivosImportados;
        private Panel panelListaArquivosImportados;
        private DataGridView dataGridView1;
        private Panel panelFormArquivosImportadosDados;
        private TextBox txAnoFinal;
        private Label lbPerFinal;
        private Label lbPerInicial;
        private TextBox txAnoInicial;
        private Label lbArquivosImportados;
        private ComboBox cbxTipoArquivos;
        private Label lbTipoArquivo;
        private Button btnFiltrarArquivos;
        private Button btnExcluir;
    }
}