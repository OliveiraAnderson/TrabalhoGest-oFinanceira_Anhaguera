﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuditA
{
    public partial class FormFiliais : Form
    {
        public FormFiliais()
        {
            InitializeComponent();
        }


        private void CarregarGridEmpresasFiliais(int codEmpresa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(CONN.strCONN))
                {
                    con.Open();

                    StringBuilder myStringBuilder = new StringBuilder();
                    myStringBuilder.Append("SELECT");
                    myStringBuilder.Append(" ISNULL(FilCodigoOriginal, '') as FilCodigoOriginal, FilCNPJ");
                    myStringBuilder.Append(", FilNome");
                    myStringBuilder.Append(", CASE WHEN FilMatriz = 0 THEN 'Sim' ELSE 'Não' END AS FilMatriz");
                    myStringBuilder.Append(", EMDB.BcoCodigo as CODIGO");
                    myStringBuilder.Append(", EMDB.BcoAtivo AS ATIVO");
                    myStringBuilder.Append(", EMDB.BcoNome");
                    myStringBuilder.Append(", EMDB.BcoServer");
                    myStringBuilder.Append(", CASE WHEN EMDB.BcoAtivo = 0 THEN 'OnLine' ELSE 'OffLine' END AS BcoAtivo");
                    myStringBuilder.Append(" FROM db_base..Empresas emp");
                    myStringBuilder.Append(" JOIN db_base..Filiais fl");
                    myStringBuilder.Append(" ON emp.EmpCodigo = fl.FilEmpresa");
                    myStringBuilder.Append(" JOIN db_base..Empresas_Bancos emdb");
                    myStringBuilder.Append(" ON emdb.BcoEmpresa = emp.EmpCodigo");
                    myStringBuilder.AppendFormat(" WHERE emp.EmpCodigo = {0}", (codEmpresa.ToString()));// 4747
                    myStringBuilder.Append(" ORDER BY FilMatriz DESC");



                    using (SqlDataAdapter da = new SqlDataAdapter(myStringBuilder.ToString(), con))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            da.Fill(dt);
                            dataGridView1.DataSource = dt;
                        }

                    }


                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao Conectar na Base de dados" + ex.Message);
            }



        }

        private void btnListarFiliaisCadastradas_Click(object sender, EventArgs e)
        {
            if (txNomeMatrizFilial.Text=="")
            {
                txNomeMatrizFilial.Text = "4747";
                int a = Convert.ToInt32(txNomeMatrizFilial.Text);
                CarregarGridEmpresasFiliais(Convert.ToInt32(a));
            }

            
        }
    }
}
