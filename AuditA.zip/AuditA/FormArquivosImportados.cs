﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuditA
{
    public partial class FormArquivosImportados : Form
    {
        public FormArquivosImportados()
        {
            InitializeComponent();
        }


        private void CarregarGridEmpresas( int ano_inicial, int ano_final)
        {



            try
            {
                using (SqlConnection con = new SqlConnection(CONN.strCONN))
                {
                    con.Open();
                    MessageBox.Show("CONECTADO AO BANCO DE DADOS");

                    var SQlQuery =
                        "SELECT arqano AS ANO, arqmes AS MES, arqarquivo AS ARQUIVO , arqnome AS NOME_ARQUIVO, arqlinhas AS TOTAL_LINHAS, arqlinhasimp AS LINHAS_IMPORTADAS FROM COOPERATIVA_TRITICOLA_SANTA_ROSA_LTDA..arquivos  where arqano>="+ano_inicial.ToString()+"  and arqano<="+ano_final.ToString();
                    using (SqlDataAdapter da = new SqlDataAdapter(SQlQuery, con))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            da.Fill(dt);
                            dataGridView1.DataSource = dt;
                        }

                    }


                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao Conectar na Base de dados" + ex.Message);
            }





        }

        private void btnFiltrarArquivos_Click(object sender, EventArgs e)
        {
            

            if (txAnoInicial.Text =="" || txAnoInicial.Text.Equals("0") 
                || txAnoFinal.Text == "" || txAnoFinal.Text.Equals("0"))
            {
                int ano_ini = Convert.ToInt32(txAnoInicial.Text="2016");
                int ano_fin = Convert.ToInt32(txAnoFinal.Text= txAnoInicial.Text);

                ano_ini = 2012;
                ano_fin = ano_ini;

                CarregarGridEmpresas(ano_ini, ano_fin);

            }else
            {
                int ano_ini = Convert.ToInt32(txAnoInicial.Text);
                int ano_fin = Convert.ToInt32(txAnoFinal.Text);

                CarregarGridEmpresas(ano_ini, ano_fin);
            }

            
        }
    }
}
