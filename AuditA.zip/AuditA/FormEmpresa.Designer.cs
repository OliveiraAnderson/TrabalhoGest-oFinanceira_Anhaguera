﻿namespace AuditA
{
    partial class FormEmpresas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbFormCadastrarEmpresas = new System.Windows.Forms.Label();
            this.txNroJOB = new System.Windows.Forms.TextBox();
            this.lbNomeEmpresa = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnCadastrarEmpresa = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txNomeFantasia = new System.Windows.Forms.TextBox();
            this.lbCNPJMatriz = new System.Windows.Forms.Label();
            this.txtCNPJMatriz = new System.Windows.Forms.TextBox();
            this.grpBoxPartBanco = new System.Windows.Forms.GroupBox();
            this.radioNao = new System.Windows.Forms.RadioButton();
            this.radioSim = new System.Windows.Forms.RadioButton();
            this.radioNaoProjetoFinalizado = new System.Windows.Forms.RadioButton();
            this.radioSimProjetoFinalizado = new System.Windows.Forms.RadioButton();
            this.StatusProjeto = new System.Windows.Forms.GroupBox();
            this.radioStatusDBNao = new System.Windows.Forms.RadioButton();
            this.radioStatusDBSim = new System.Windows.Forms.RadioButton();
            this.grpStatusBanco = new System.Windows.Forms.GroupBox();
            this.btnAlterarEmpresa = new System.Windows.Forms.Button();
            this.panelListaEmpresasCadastradas = new System.Windows.Forms.Panel();
            this.dgvListaEmpresaCadastradas = new System.Windows.Forms.DataGridView();
            this.grpBoxPartBanco.SuspendLayout();
            this.StatusProjeto.SuspendLayout();
            this.grpStatusBanco.SuspendLayout();
            this.panelListaEmpresasCadastradas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaEmpresaCadastradas)).BeginInit();
            this.SuspendLayout();
            // 
            // lbFormCadastrarEmpresas
            // 
            this.lbFormCadastrarEmpresas.AutoSize = true;
            this.lbFormCadastrarEmpresas.BackColor = System.Drawing.Color.White;
            this.lbFormCadastrarEmpresas.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbFormCadastrarEmpresas.ForeColor = System.Drawing.Color.DimGray;
            this.lbFormCadastrarEmpresas.Location = new System.Drawing.Point(5, 4);
            this.lbFormCadastrarEmpresas.Name = "lbFormCadastrarEmpresas";
            this.lbFormCadastrarEmpresas.Size = new System.Drawing.Size(438, 45);
            this.lbFormCadastrarEmpresas.TabIndex = 0;
            this.lbFormCadastrarEmpresas.Text = "Cadastrar Empresas";
            this.lbFormCadastrarEmpresas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txNroJOB
            // 
            this.txNroJOB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txNroJOB.Location = new System.Drawing.Point(12, 88);
            this.txNroJOB.Name = "txNroJOB";
            this.txNroJOB.Size = new System.Drawing.Size(174, 31);
            this.txNroJOB.TabIndex = 1;
            // 
            // lbNomeEmpresa
            // 
            this.lbNomeEmpresa.AutoSize = true;
            this.lbNomeEmpresa.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbNomeEmpresa.ForeColor = System.Drawing.Color.DimGray;
            this.lbNomeEmpresa.Location = new System.Drawing.Point(15, 67);
            this.lbNomeEmpresa.Name = "lbNomeEmpresa";
            this.lbNomeEmpresa.Size = new System.Drawing.Size(86, 18);
            this.lbNomeEmpresa.TabIndex = 2;
            this.lbNomeEmpresa.Text = "Nro JOB:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Red;
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancelar.Location = new System.Drawing.Point(822, 88);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(129, 31);
            this.btnCancelar.TabIndex = 22;
            this.btnCancelar.Text = "&Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.Moccasin;
            this.btnExcluir.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExcluir.Location = new System.Drawing.Point(957, 88);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(129, 31);
            this.btnExcluir.TabIndex = 21;
            this.btnExcluir.Text = "&Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            // 
            // btnCadastrarEmpresa
            // 
            this.btnCadastrarEmpresa.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCadastrarEmpresa.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnCadastrarEmpresa.FlatAppearance.BorderSize = 0;
            this.btnCadastrarEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarEmpresa.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCadastrarEmpresa.Location = new System.Drawing.Point(549, 88);
            this.btnCadastrarEmpresa.Name = "btnCadastrarEmpresa";
            this.btnCadastrarEmpresa.Size = new System.Drawing.Size(129, 31);
            this.btnCadastrarEmpresa.TabIndex = 19;
            this.btnCadastrarEmpresa.Text = "&Cadastrar";
            this.btnCadastrarEmpresa.UseVisualStyleBackColor = false;
            this.btnCadastrarEmpresa.Click += new System.EventHandler(this.btnCadastrarEmpresa_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(15, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 18);
            this.label1.TabIndex = 24;
            this.label1.Text = "Razão Social:";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(12, 155);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(524, 31);
            this.textBox2.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(15, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 18);
            this.label2.TabIndex = 26;
            this.label2.Text = "Nome Fantasia:";
            // 
            // txNomeFantasia
            // 
            this.txNomeFantasia.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txNomeFantasia.Location = new System.Drawing.Point(12, 219);
            this.txNomeFantasia.Name = "txNomeFantasia";
            this.txNomeFantasia.Size = new System.Drawing.Size(524, 31);
            this.txNomeFantasia.TabIndex = 25;
            // 
            // lbCNPJMatriz
            // 
            this.lbCNPJMatriz.AutoSize = true;
            this.lbCNPJMatriz.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbCNPJMatriz.ForeColor = System.Drawing.Color.DimGray;
            this.lbCNPJMatriz.Location = new System.Drawing.Point(15, 269);
            this.lbCNPJMatriz.Name = "lbCNPJMatriz";
            this.lbCNPJMatriz.Size = new System.Drawing.Size(141, 18);
            this.lbCNPJMatriz.TabIndex = 28;
            this.lbCNPJMatriz.Text = "CNPJ da Matriz";
            // 
            // txtCNPJMatriz
            // 
            this.txtCNPJMatriz.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCNPJMatriz.Location = new System.Drawing.Point(12, 295);
            this.txtCNPJMatriz.Name = "txtCNPJMatriz";
            this.txtCNPJMatriz.PlaceholderText = "00.000.000/0000-00";
            this.txtCNPJMatriz.Size = new System.Drawing.Size(220, 31);
            this.txtCNPJMatriz.TabIndex = 27;
            // 
            // grpBoxPartBanco
            // 
            this.grpBoxPartBanco.Controls.Add(this.radioNao);
            this.grpBoxPartBanco.Controls.Add(this.radioSim);
            this.grpBoxPartBanco.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpBoxPartBanco.ForeColor = System.Drawing.Color.DimGray;
            this.grpBoxPartBanco.Location = new System.Drawing.Point(248, 267);
            this.grpBoxPartBanco.Name = "grpBoxPartBanco";
            this.grpBoxPartBanco.Size = new System.Drawing.Size(263, 63);
            this.grpBoxPartBanco.TabIndex = 29;
            this.grpBoxPartBanco.TabStop = false;
            this.grpBoxPartBanco.Text = "Partição do Banco";
            // 
            // radioNao
            // 
            this.radioNao.AutoSize = true;
            this.radioNao.Location = new System.Drawing.Point(100, 28);
            this.radioNao.Name = "radioNao";
            this.radioNao.Size = new System.Drawing.Size(70, 27);
            this.radioNao.TabIndex = 1;
            this.radioNao.TabStop = true;
            this.radioNao.Text = "Não";
            this.radioNao.UseVisualStyleBackColor = true;
            // 
            // radioSim
            // 
            this.radioSim.AutoSize = true;
            this.radioSim.Location = new System.Drawing.Point(25, 28);
            this.radioSim.Name = "radioSim";
            this.radioSim.Size = new System.Drawing.Size(69, 27);
            this.radioSim.TabIndex = 0;
            this.radioSim.TabStop = true;
            this.radioSim.Text = "Sim";
            this.radioSim.UseVisualStyleBackColor = true;
            // 
            // radioNaoProjetoFinalizado
            // 
            this.radioNaoProjetoFinalizado.AutoSize = true;
            this.radioNaoProjetoFinalizado.Location = new System.Drawing.Point(120, 28);
            this.radioNaoProjetoFinalizado.Name = "radioNaoProjetoFinalizado";
            this.radioNaoProjetoFinalizado.Size = new System.Drawing.Size(70, 27);
            this.radioNaoProjetoFinalizado.TabIndex = 1;
            this.radioNaoProjetoFinalizado.TabStop = true;
            this.radioNaoProjetoFinalizado.Text = "Não";
            this.radioNaoProjetoFinalizado.UseVisualStyleBackColor = true;
            // 
            // radioSimProjetoFinalizado
            // 
            this.radioSimProjetoFinalizado.AutoSize = true;
            this.radioSimProjetoFinalizado.Location = new System.Drawing.Point(28, 28);
            this.radioSimProjetoFinalizado.Name = "radioSimProjetoFinalizado";
            this.radioSimProjetoFinalizado.Size = new System.Drawing.Size(69, 27);
            this.radioSimProjetoFinalizado.TabIndex = 0;
            this.radioSimProjetoFinalizado.TabStop = true;
            this.radioSimProjetoFinalizado.Text = "Sim";
            this.radioSimProjetoFinalizado.UseVisualStyleBackColor = true;
            // 
            // StatusProjeto
            // 
            this.StatusProjeto.Controls.Add(this.radioNaoProjetoFinalizado);
            this.StatusProjeto.Controls.Add(this.radioSimProjetoFinalizado);
            this.StatusProjeto.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StatusProjeto.ForeColor = System.Drawing.Color.DimGray;
            this.StatusProjeto.Location = new System.Drawing.Point(530, 267);
            this.StatusProjeto.Name = "StatusProjeto";
            this.StatusProjeto.Size = new System.Drawing.Size(263, 63);
            this.StatusProjeto.TabIndex = 30;
            this.StatusProjeto.TabStop = false;
            this.StatusProjeto.Text = "Projeto finalizado";
            // 
            // radioStatusDBNao
            // 
            this.radioStatusDBNao.AutoSize = true;
            this.radioStatusDBNao.Location = new System.Drawing.Point(136, 28);
            this.radioStatusDBNao.Name = "radioStatusDBNao";
            this.radioStatusDBNao.Size = new System.Drawing.Size(106, 27);
            this.radioStatusDBNao.TabIndex = 1;
            this.radioStatusDBNao.TabStop = true;
            this.radioStatusDBNao.Text = "OffLine";
            this.radioStatusDBNao.UseVisualStyleBackColor = true;
            // 
            // radioStatusDBSim
            // 
            this.radioStatusDBSim.AutoSize = true;
            this.radioStatusDBSim.Location = new System.Drawing.Point(28, 28);
            this.radioStatusDBSim.Name = "radioStatusDBSim";
            this.radioStatusDBSim.Size = new System.Drawing.Size(104, 27);
            this.radioStatusDBSim.TabIndex = 0;
            this.radioStatusDBSim.TabStop = true;
            this.radioStatusDBSim.Text = "OnLine";
            this.radioStatusDBSim.UseVisualStyleBackColor = true;
            // 
            // grpStatusBanco
            // 
            this.grpStatusBanco.Controls.Add(this.radioStatusDBNao);
            this.grpStatusBanco.Controls.Add(this.radioStatusDBSim);
            this.grpStatusBanco.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpStatusBanco.ForeColor = System.Drawing.Color.DimGray;
            this.grpStatusBanco.Location = new System.Drawing.Point(815, 269);
            this.grpStatusBanco.Name = "grpStatusBanco";
            this.grpStatusBanco.Size = new System.Drawing.Size(263, 63);
            this.grpStatusBanco.TabIndex = 31;
            this.grpStatusBanco.TabStop = false;
            this.grpStatusBanco.Text = "Status Banco:";
            // 
            // btnAlterarEmpresa
            // 
            this.btnAlterarEmpresa.BackColor = System.Drawing.Color.DimGray;
            this.btnAlterarEmpresa.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAlterarEmpresa.FlatAppearance.BorderSize = 0;
            this.btnAlterarEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlterarEmpresa.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAlterarEmpresa.Location = new System.Drawing.Point(687, 88);
            this.btnAlterarEmpresa.Name = "btnAlterarEmpresa";
            this.btnAlterarEmpresa.Size = new System.Drawing.Size(129, 31);
            this.btnAlterarEmpresa.TabIndex = 20;
            this.btnAlterarEmpresa.Text = "&Alterar";
            this.btnAlterarEmpresa.UseVisualStyleBackColor = false;
            // 
            // panelListaEmpresasCadastradas
            // 
            this.panelListaEmpresasCadastradas.Controls.Add(this.dgvListaEmpresaCadastradas);
            this.panelListaEmpresasCadastradas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelListaEmpresasCadastradas.Location = new System.Drawing.Point(0, 338);
            this.panelListaEmpresasCadastradas.Name = "panelListaEmpresasCadastradas";
            this.panelListaEmpresasCadastradas.Size = new System.Drawing.Size(1180, 345);
            this.panelListaEmpresasCadastradas.TabIndex = 32;
            // 
            // dgvListaEmpresaCadastradas
            // 
            this.dgvListaEmpresaCadastradas.AllowUserToOrderColumns = true;
            this.dgvListaEmpresaCadastradas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaEmpresaCadastradas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaEmpresaCadastradas.Location = new System.Drawing.Point(0, 0);
            this.dgvListaEmpresaCadastradas.Name = "dgvListaEmpresaCadastradas";
            this.dgvListaEmpresaCadastradas.RowTemplate.Height = 25;
            this.dgvListaEmpresaCadastradas.Size = new System.Drawing.Size(1180, 345);
            this.dgvListaEmpresaCadastradas.TabIndex = 0;
            // 
            // FormEmpresas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1180, 683);
            this.Controls.Add(this.panelListaEmpresasCadastradas);
            this.Controls.Add(this.grpStatusBanco);
            this.Controls.Add(this.StatusProjeto);
            this.Controls.Add(this.grpBoxPartBanco);
            this.Controls.Add(this.lbCNPJMatriz);
            this.Controls.Add(this.txtCNPJMatriz);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txNomeFantasia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnAlterarEmpresa);
            this.Controls.Add(this.btnCadastrarEmpresa);
            this.Controls.Add(this.lbNomeEmpresa);
            this.Controls.Add(this.txNroJOB);
            this.Controls.Add(this.lbFormCadastrarEmpresas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEmpresas";
            this.Text = "Empresas";
            this.Load += new System.EventHandler(this.FormEmpresas_Load);
            this.grpBoxPartBanco.ResumeLayout(false);
            this.grpBoxPartBanco.PerformLayout();
            this.StatusProjeto.ResumeLayout(false);
            this.StatusProjeto.PerformLayout();
            this.grpStatusBanco.ResumeLayout(false);
            this.grpStatusBanco.PerformLayout();
            this.panelListaEmpresasCadastradas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaEmpresaCadastradas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbFormCadastrarEmpresas;
        private TextBox txNroJOB;
        private Label lbNomeEmpresa;
        private Button btnCancelar;
        private Button btnExcluir;
        private Button btnCadastrarEmpresa;
        private Label label1;
        private TextBox textBox2;
        private Label label2;
        private TextBox txNomeFantasia;
        private Label lbCNPJMatriz;
        private TextBox txtCNPJMatriz;
        private GroupBox grpBoxPartBanco;
        private RadioButton radioNao;
        private RadioButton radioSim;
        private RadioButton radioNaoProjetoFinalizado;
        private RadioButton radioSimProjetoFinalizado;
        private GroupBox StatusProjeto;
        private RadioButton radioStatusDBNao;
        private RadioButton radioStatusDBSim;
        private GroupBox grpStatusBanco;
        private Button btnAlterarEmpresa;
        private Panel panelListaEmpresasCadastradas;
        private DataGridView dgvListaEmpresaCadastradas;
    }
}