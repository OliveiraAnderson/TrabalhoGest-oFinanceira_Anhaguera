﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tulpep.NotificationWindow;

namespace AuditA
{
    public partial class FormSplashAuditor : Form
    {
        public FormSplashAuditor()
        {
            InitializeComponent();
            PopupNotificacao();
            
        }

        private void PopupNotificacao()
        {
            PopupNotifier popup = new PopupNotifier();
            popup.Image = Properties.Resources.info;
            popup.TitleColor = Color.DimGray;
            popup.HeaderColor = Color.DimGray;
            popup.TitleText = "Olá Senhor, Anderson Oliveira";
            popup.ContentText = "Aguarde alguns segundo, pois estamos ajustando algumas configurações iniciais!";
          

            popup.Popup();//Show()

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            progressBar1.Increment(2);
            if (progressBar1.Value==100)
            {
                timer1.Enabled = false;
   
              
                PanelNavTitle formPrincipal = new PanelNavTitle();                
                formPrincipal.Show();
                
                this.Hide();

            }
            lbProgress.Text = "Loading "+progressBar1.Value.ToString() + "%";
    



        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
