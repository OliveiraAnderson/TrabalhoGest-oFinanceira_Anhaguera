﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuditA
{
    public partial class FormEmpresas : Form
    {
        public FormEmpresas()
        {
            InitializeComponent();
            
        }


        


        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }


        private void CarregarGridEmpresas()
        {



            try
            {
                using (SqlConnection con = new SqlConnection(CONN.strCONN))
                {
                    con.Open();
                    MessageBox.Show("CONECTADO AO BANCO DE DADOS");
                     
                    var SQlQuery = 
                        "SELECT arqano, arqmes, arqarquivo, arqnome, arqlinhas, arqlinhasimp FROM COOPERATIVA_TRITICOLA_SANTA_ROSA_LTDA..arquivos";
                        using (SqlDataAdapter da = new SqlDataAdapter(SQlQuery, con))
                        {
                            using (DataTable dt = new DataTable())
                            {
                              da.Fill(dt);
                              dgvListaEmpresaCadastradas.DataSource = dt;
                            }

                        }


                }

            }
            catch (Exception ex)
            {

            MessageBox.Show("Erro ao Conectar na Base de dados" + ex.Message);
            }



            

        }

        private void FormEmpresas_Load(object sender, EventArgs e)
        {
            // CarregarGridEmpresas();
        }

        private void btnCadastrarEmpresa_Click(object sender, EventArgs e)
        {
            CarregarGridEmpresas();
        }
    }
}
