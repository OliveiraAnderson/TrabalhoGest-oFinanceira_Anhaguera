﻿namespace AuditA
{
    partial class FormImportacaoArquivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelFormImportacaoArquivos = new System.Windows.Forms.Panel();
            this.btnCancelarImportacao = new System.Windows.Forms.Button();
            this.btnImportarArquivos = new System.Windows.Forms.Button();
            this.ibtnLocalizar = new FontAwesome.Sharp.IconButton();
            this.lbDiretorioOrigem = new System.Windows.Forms.Label();
            this.txDiretorioOrigem = new System.Windows.Forms.TextBox();
            this.lbImportacaoArquivos = new System.Windows.Forms.Label();
            this.OpenDiretorioOrigem = new System.Windows.Forms.OpenFileDialog();
            this.panelFormImportacaoStatusdasLinhasArquivo = new System.Windows.Forms.Panel();
            this.richTextBoxAtualizaLinhasImportadas = new System.Windows.Forms.RichTextBox();
            this.panelFormImportacaoArquivos.SuspendLayout();
            this.panelFormImportacaoStatusdasLinhasArquivo.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelFormImportacaoArquivos
            // 
            this.panelFormImportacaoArquivos.Controls.Add(this.btnCancelarImportacao);
            this.panelFormImportacaoArquivos.Controls.Add(this.btnImportarArquivos);
            this.panelFormImportacaoArquivos.Controls.Add(this.ibtnLocalizar);
            this.panelFormImportacaoArquivos.Controls.Add(this.lbDiretorioOrigem);
            this.panelFormImportacaoArquivos.Controls.Add(this.txDiretorioOrigem);
            this.panelFormImportacaoArquivos.Controls.Add(this.lbImportacaoArquivos);
            this.panelFormImportacaoArquivos.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFormImportacaoArquivos.Location = new System.Drawing.Point(0, 0);
            this.panelFormImportacaoArquivos.Name = "panelFormImportacaoArquivos";
            this.panelFormImportacaoArquivos.Size = new System.Drawing.Size(1164, 124);
            this.panelFormImportacaoArquivos.TabIndex = 0;
            // 
            // btnCancelarImportacao
            // 
            this.btnCancelarImportacao.BackColor = System.Drawing.Color.Red;
            this.btnCancelarImportacao.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnCancelarImportacao.FlatAppearance.BorderSize = 0;
            this.btnCancelarImportacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelarImportacao.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancelarImportacao.Location = new System.Drawing.Point(924, 64);
            this.btnCancelarImportacao.Name = "btnCancelarImportacao";
            this.btnCancelarImportacao.Size = new System.Drawing.Size(129, 31);
            this.btnCancelarImportacao.TabIndex = 20;
            this.btnCancelarImportacao.Text = "&Cancelar";
            this.btnCancelarImportacao.UseVisualStyleBackColor = false;
            // 
            // btnImportarArquivos
            // 
            this.btnImportarArquivos.BackColor = System.Drawing.Color.DimGray;
            this.btnImportarArquivos.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnImportarArquivos.FlatAppearance.BorderSize = 0;
            this.btnImportarArquivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportarArquivos.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnImportarArquivos.Location = new System.Drawing.Point(789, 64);
            this.btnImportarArquivos.Name = "btnImportarArquivos";
            this.btnImportarArquivos.Size = new System.Drawing.Size(129, 31);
            this.btnImportarArquivos.TabIndex = 19;
            this.btnImportarArquivos.Text = "&Importar";
            this.btnImportarArquivos.UseVisualStyleBackColor = false;
            // 
            // ibtnLocalizar
            // 
            this.ibtnLocalizar.BackColor = System.Drawing.Color.White;
            this.ibtnLocalizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ibtnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnLocalizar.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ibtnLocalizar.ForeColor = System.Drawing.Color.DimGray;
            this.ibtnLocalizar.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.ibtnLocalizar.IconColor = System.Drawing.Color.DimGray;
            this.ibtnLocalizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnLocalizar.IconSize = 35;
            this.ibtnLocalizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnLocalizar.Location = new System.Drawing.Point(737, 64);
            this.ibtnLocalizar.Name = "ibtnLocalizar";
            this.ibtnLocalizar.Size = new System.Drawing.Size(45, 31);
            this.ibtnLocalizar.TabIndex = 3;
            this.ibtnLocalizar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ibtnLocalizar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ibtnLocalizar.UseVisualStyleBackColor = false;
            // 
            // lbDiretorioOrigem
            // 
            this.lbDiretorioOrigem.AutoSize = true;
            this.lbDiretorioOrigem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbDiretorioOrigem.ForeColor = System.Drawing.Color.DimGray;
            this.lbDiretorioOrigem.Location = new System.Drawing.Point(15, 40);
            this.lbDiretorioOrigem.Name = "lbDiretorioOrigem";
            this.lbDiretorioOrigem.Size = new System.Drawing.Size(250, 18);
            this.lbDiretorioOrigem.TabIndex = 2;
            this.lbDiretorioOrigem.Text = "Pasta Origem dos Arquivos:";
            // 
            // txDiretorioOrigem
            // 
            this.txDiretorioOrigem.Font = new System.Drawing.Font("Verdana", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.txDiretorioOrigem.ForeColor = System.Drawing.Color.Green;
            this.txDiretorioOrigem.Location = new System.Drawing.Point(12, 68);
            this.txDiretorioOrigem.Name = "txDiretorioOrigem";
            this.txDiretorioOrigem.PlaceholderText = "Informe a pasta de origem dos arquivos a serem importados...";
            this.txDiretorioOrigem.Size = new System.Drawing.Size(720, 26);
            this.txDiretorioOrigem.TabIndex = 1;
            // 
            // lbImportacaoArquivos
            // 
            this.lbImportacaoArquivos.AutoSize = true;
            this.lbImportacaoArquivos.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbImportacaoArquivos.ForeColor = System.Drawing.Color.DimGray;
            this.lbImportacaoArquivos.Location = new System.Drawing.Point(12, 9);
            this.lbImportacaoArquivos.Name = "lbImportacaoArquivos";
            this.lbImportacaoArquivos.Size = new System.Drawing.Size(268, 23);
            this.lbImportacaoArquivos.TabIndex = 0;
            this.lbImportacaoArquivos.Text = "Importação de Arquivos";
            // 
            // OpenDiretorioOrigem
            // 
            this.OpenDiretorioOrigem.FileName = "openFileImportacao";
            this.OpenDiretorioOrigem.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // panelFormImportacaoStatusdasLinhasArquivo
            // 
            this.panelFormImportacaoStatusdasLinhasArquivo.Controls.Add(this.richTextBoxAtualizaLinhasImportadas);
            this.panelFormImportacaoStatusdasLinhasArquivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFormImportacaoStatusdasLinhasArquivo.Location = new System.Drawing.Point(0, 124);
            this.panelFormImportacaoStatusdasLinhasArquivo.Name = "panelFormImportacaoStatusdasLinhasArquivo";
            this.panelFormImportacaoStatusdasLinhasArquivo.Size = new System.Drawing.Size(1164, 520);
            this.panelFormImportacaoStatusdasLinhasArquivo.TabIndex = 1;
            // 
            // richTextBoxAtualizaLinhasImportadas
            // 
            this.richTextBoxAtualizaLinhasImportadas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxAtualizaLinhasImportadas.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.richTextBoxAtualizaLinhasImportadas.ForeColor = System.Drawing.Color.DimGray;
            this.richTextBoxAtualizaLinhasImportadas.Location = new System.Drawing.Point(0, 0);
            this.richTextBoxAtualizaLinhasImportadas.Name = "richTextBoxAtualizaLinhasImportadas";
            this.richTextBoxAtualizaLinhasImportadas.Size = new System.Drawing.Size(1164, 520);
            this.richTextBoxAtualizaLinhasImportadas.TabIndex = 0;
            this.richTextBoxAtualizaLinhasImportadas.Text = "\nDiretório Origem: {PastaOrigem}\n\nTotal de Arquivos a serem importados: {Qtde_Arq" +
    "uivos_Selecionado}\n\n\nImportação realizada com sucesso!\n\n";
            // 
            // FormImportacaoArquivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1164, 644);
            this.Controls.Add(this.panelFormImportacaoStatusdasLinhasArquivo);
            this.Controls.Add(this.panelFormImportacaoArquivos);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormImportacaoArquivos";
            this.Text = "Importação de Arquivos";
            this.panelFormImportacaoArquivos.ResumeLayout(false);
            this.panelFormImportacaoArquivos.PerformLayout();
            this.panelFormImportacaoStatusdasLinhasArquivo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panelFormImportacaoArquivos;
        private Label lbImportacaoArquivos;
        private OpenFileDialog OpenDiretorioOrigem;
        private FontAwesome.Sharp.IconButton ibtnLocalizar;
        private Label lbDiretorioOrigem;
        private TextBox txDiretorioOrigem;
        private Button btnCancelarImportacao;
        private Button btnImportarArquivos;
        private Panel panelFormImportacaoStatusdasLinhasArquivo;
        private RichTextBox richTextBoxAtualizaLinhasImportadas;
    }
}