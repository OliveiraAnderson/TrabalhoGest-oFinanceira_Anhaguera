﻿namespace AuditA
{
    partial class FormFiliais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelFormCadFilais = new System.Windows.Forms.Panel();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panelCadastrarFilial = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lbMatrizStatus = new System.Windows.Forms.Label();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCNPJMatrizFilial = new System.Windows.Forms.TextBox();
            this.btnImportarFilial = new System.Windows.Forms.Button();
            this.btnListarFiliaisCadastradas = new System.Windows.Forms.Button();
            this.lbNomeFilial = new System.Windows.Forms.Label();
            this.txNomeMatrizFilial = new System.Windows.Forms.TextBox();
            this.lbFormCadastrarFilial = new System.Windows.Forms.Label();
            this.PanelFormCadFilais.SuspendLayout();
            this.panelCadastrarFilial.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelFormCadFilais
            // 
            this.PanelFormCadFilais.BackColor = System.Drawing.Color.White;
            this.PanelFormCadFilais.Controls.Add(this.btnExcluir);
            this.PanelFormCadFilais.Controls.Add(this.button2);
            this.PanelFormCadFilais.Controls.Add(this.panelCadastrarFilial);
            this.PanelFormCadFilais.Controls.Add(this.comboBox1);
            this.PanelFormCadFilais.Controls.Add(this.lbMatrizStatus);
            this.PanelFormCadFilais.Controls.Add(this.btnAlterar);
            this.PanelFormCadFilais.Controls.Add(this.label1);
            this.PanelFormCadFilais.Controls.Add(this.txtCNPJMatrizFilial);
            this.PanelFormCadFilais.Controls.Add(this.btnImportarFilial);
            this.PanelFormCadFilais.Controls.Add(this.btnListarFiliaisCadastradas);
            this.PanelFormCadFilais.Controls.Add(this.lbNomeFilial);
            this.PanelFormCadFilais.Controls.Add(this.txNomeMatrizFilial);
            this.PanelFormCadFilais.Controls.Add(this.lbFormCadastrarFilial);
            this.PanelFormCadFilais.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelFormCadFilais.Location = new System.Drawing.Point(0, 0);
            this.PanelFormCadFilais.Name = "PanelFormCadFilais";
            this.PanelFormCadFilais.Size = new System.Drawing.Size(1180, 683);
            this.PanelFormCadFilais.TabIndex = 0;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.Moccasin;
            this.btnExcluir.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExcluir.Location = new System.Drawing.Point(1040, 69);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(129, 31);
            this.btnExcluir.TabIndex = 19;
            this.btnExcluir.Text = "&Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(905, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 31);
            this.button2.TabIndex = 18;
            this.button2.Text = "&Cancelar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // panelCadastrarFilial
            // 
            this.panelCadastrarFilial.Controls.Add(this.dataGridView1);
            this.panelCadastrarFilial.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelCadastrarFilial.Location = new System.Drawing.Point(0, 192);
            this.panelCadastrarFilial.Name = "panelCadastrarFilial";
            this.panelCadastrarFilial.Size = new System.Drawing.Size(1180, 491);
            this.panelCadastrarFilial.TabIndex = 17;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(1180, 491);
            this.dataGridView1.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "SIM",
            "NÃO"});
            this.comboBox1.Location = new System.Drawing.Point(252, 134);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(141, 31);
            this.comboBox1.TabIndex = 16;
            // 
            // lbMatrizStatus
            // 
            this.lbMatrizStatus.AutoSize = true;
            this.lbMatrizStatus.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbMatrizStatus.ForeColor = System.Drawing.Color.DimGray;
            this.lbMatrizStatus.Location = new System.Drawing.Point(255, 116);
            this.lbMatrizStatus.Name = "lbMatrizStatus";
            this.lbMatrizStatus.Size = new System.Drawing.Size(132, 18);
            this.lbMatrizStatus.TabIndex = 15;
            this.lbMatrizStatus.Text = "Matriz ou Filial";
            // 
            // btnAlterar
            // 
            this.btnAlterar.BackColor = System.Drawing.Color.Aqua;
            this.btnAlterar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAlterar.FlatAppearance.BorderSize = 0;
            this.btnAlterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlterar.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAlterar.Location = new System.Drawing.Point(770, 69);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(129, 31);
            this.btnAlterar.TabIndex = 13;
            this.btnAlterar.Text = "&Alterar";
            this.btnAlterar.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(4, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "CNPJ/ Matriz Filial";
            // 
            // txtCNPJMatrizFilial
            // 
            this.txtCNPJMatrizFilial.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCNPJMatrizFilial.Location = new System.Drawing.Point(4, 134);
            this.txtCNPJMatrizFilial.Name = "txtCNPJMatrizFilial";
            this.txtCNPJMatrizFilial.PlaceholderText = "00.000.000/0000-00";
            this.txtCNPJMatrizFilial.Size = new System.Drawing.Size(220, 31);
            this.txtCNPJMatrizFilial.TabIndex = 11;
            // 
            // btnImportarFilial
            // 
            this.btnImportarFilial.BackColor = System.Drawing.Color.DimGray;
            this.btnImportarFilial.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnImportarFilial.FlatAppearance.BorderSize = 0;
            this.btnImportarFilial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportarFilial.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnImportarFilial.Location = new System.Drawing.Point(631, 69);
            this.btnImportarFilial.Name = "btnImportarFilial";
            this.btnImportarFilial.Size = new System.Drawing.Size(129, 31);
            this.btnImportarFilial.TabIndex = 10;
            this.btnImportarFilial.Text = "&Importar";
            this.btnImportarFilial.UseVisualStyleBackColor = false;
            // 
            // btnListarFiliaisCadastradas
            // 
            this.btnListarFiliaisCadastradas.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnListarFiliaisCadastradas.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnListarFiliaisCadastradas.FlatAppearance.BorderSize = 0;
            this.btnListarFiliaisCadastradas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListarFiliaisCadastradas.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnListarFiliaisCadastradas.Location = new System.Drawing.Point(493, 69);
            this.btnListarFiliaisCadastradas.Name = "btnListarFiliaisCadastradas";
            this.btnListarFiliaisCadastradas.Size = new System.Drawing.Size(129, 31);
            this.btnListarFiliaisCadastradas.TabIndex = 9;
            this.btnListarFiliaisCadastradas.Text = "&Listar";
            this.btnListarFiliaisCadastradas.UseVisualStyleBackColor = false;
            this.btnListarFiliaisCadastradas.Click += new System.EventHandler(this.btnListarFiliaisCadastradas_Click);
            // 
            // lbNomeFilial
            // 
            this.lbNomeFilial.AutoSize = true;
            this.lbNomeFilial.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbNomeFilial.ForeColor = System.Drawing.Color.DimGray;
            this.lbNomeFilial.Location = new System.Drawing.Point(4, 51);
            this.lbNomeFilial.Name = "lbNomeFilial";
            this.lbNomeFilial.Size = new System.Drawing.Size(172, 18);
            this.lbNomeFilial.TabIndex = 8;
            this.lbNomeFilial.Text = "Nome Matriz/ Filial";
            // 
            // txNomeMatrizFilial
            // 
            this.txNomeMatrizFilial.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txNomeMatrizFilial.Location = new System.Drawing.Point(4, 69);
            this.txNomeMatrizFilial.Name = "txNomeMatrizFilial";
            this.txNomeMatrizFilial.Size = new System.Drawing.Size(479, 31);
            this.txNomeMatrizFilial.TabIndex = 7;
            // 
            // lbFormCadastrarFilial
            // 
            this.lbFormCadastrarFilial.AutoSize = true;
            this.lbFormCadastrarFilial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbFormCadastrarFilial.Font = new System.Drawing.Font("Verdana", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbFormCadastrarFilial.ForeColor = System.Drawing.Color.DimGray;
            this.lbFormCadastrarFilial.Location = new System.Drawing.Point(4, 3);
            this.lbFormCadastrarFilial.Name = "lbFormCadastrarFilial";
            this.lbFormCadastrarFilial.Size = new System.Drawing.Size(307, 38);
            this.lbFormCadastrarFilial.TabIndex = 0;
            this.lbFormCadastrarFilial.Text = "Cadastrar Filiais";
            // 
            // FormFiliais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 683);
            this.Controls.Add(this.PanelFormCadFilais);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormFiliais";
            this.Text = "Filiais";
            this.PanelFormCadFilais.ResumeLayout(false);
            this.PanelFormCadFilais.PerformLayout();
            this.panelCadastrarFilial.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel PanelFormCadFilais;
        private Label lbFormCadastrarFilial;
        private Button btnImportarFilial;
        private Button btnListarFiliaisCadastradas;
        private Label lbNomeFilial;
        private TextBox txNomeMatrizFilial;
        private Label label1;
        private TextBox txtCNPJMatrizFilial;
        private Button btnAlterar;
        private Panel panelCadastrarFilial;
        private DataGridView dataGridView1;
        private ComboBox comboBox1;
        private Label lbMatrizStatus;
        private Button button2;
        private Button btnExcluir;
    }
}