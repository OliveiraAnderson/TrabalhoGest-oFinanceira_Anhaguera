﻿namespace AuditA
{
    partial class FormModuloSQLSERVER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormModuloSQLSERVER));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbDescritivoModulo = new System.Windows.Forms.Label();
            this.richTextBoxDescricaoModulo = new System.Windows.Forms.RichTextBox();
            this.tabControlScriptSQL = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExecutarComando = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnExportar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.tabControlScriptSQL.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lbDescritivoModulo);
            this.panel1.Controls.Add(this.richTextBoxDescricaoModulo);
            this.panel1.Controls.Add(this.tabControlScriptSQL);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1180, 683);
            this.panel1.TabIndex = 0;
            // 
            // lbDescritivoModulo
            // 
            this.lbDescritivoModulo.AutoSize = true;
            this.lbDescritivoModulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbDescritivoModulo.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbDescritivoModulo.ForeColor = System.Drawing.Color.DimGray;
            this.lbDescritivoModulo.Location = new System.Drawing.Point(0, 0);
            this.lbDescritivoModulo.Name = "lbDescritivoModulo";
            this.lbDescritivoModulo.Size = new System.Drawing.Size(434, 32);
            this.lbDescritivoModulo.TabIndex = 2;
            this.lbDescritivoModulo.Text = "Módulo de Consulta via SQL";
            // 
            // richTextBoxDescricaoModulo
            // 
            this.richTextBoxDescricaoModulo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.richTextBoxDescricaoModulo.ForeColor = System.Drawing.Color.DimGray;
            this.richTextBoxDescricaoModulo.Location = new System.Drawing.Point(0, 35);
            this.richTextBoxDescricaoModulo.Name = "richTextBoxDescricaoModulo";
            this.richTextBoxDescricaoModulo.ReadOnly = true;
            this.richTextBoxDescricaoModulo.Size = new System.Drawing.Size(1180, 308);
            this.richTextBoxDescricaoModulo.TabIndex = 1;
            this.richTextBoxDescricaoModulo.Text = resources.GetString("richTextBoxDescricaoModulo.Text");
            // 
            // tabControlScriptSQL
            // 
            this.tabControlScriptSQL.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControlScriptSQL.Controls.Add(this.tabPage1);
            this.tabControlScriptSQL.Controls.Add(this.tabPage2);
            this.tabControlScriptSQL.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControlScriptSQL.Location = new System.Drawing.Point(0, 343);
            this.tabControlScriptSQL.Name = "tabControlScriptSQL";
            this.tabControlScriptSQL.SelectedIndex = 0;
            this.tabControlScriptSQL.Size = new System.Drawing.Size(1180, 340);
            this.tabControlScriptSQL.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.richTextBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 35);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1172, 301);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Script SQL SERVER";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnExecutarComando);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(3, 251);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1166, 47);
            this.panel2.TabIndex = 1;
            // 
            // btnExecutarComando
            // 
            this.btnExecutarComando.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnExecutarComando.ForeColor = System.Drawing.Color.DimGray;
            this.btnExecutarComando.Location = new System.Drawing.Point(5, 3);
            this.btnExecutarComando.Name = "btnExecutarComando";
            this.btnExecutarComando.Size = new System.Drawing.Size(138, 41);
            this.btnExecutarComando.TabIndex = 0;
            this.btnExecutarComando.Text = "Executar";
            this.btnExecutarComando.UseVisualStyleBackColor = false;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.ForeColor = System.Drawing.Color.Indigo;
            this.richTextBox2.Location = new System.Drawing.Point(3, 3);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(1166, 295);
            this.richTextBox2.TabIndex = 0;
            this.richTextBox2.Text = resources.GetString("richTextBox2.Text");
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 35);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1172, 301);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ResultSet SQL";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnExportar);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(3, 251);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1166, 47);
            this.panel3.TabIndex = 2;
            // 
            // btnExportar
            // 
            this.btnExportar.BackColor = System.Drawing.Color.Aqua;
            this.btnExportar.ForeColor = System.Drawing.Color.DimGray;
            this.btnExportar.Location = new System.Drawing.Point(5, 3);
            this.btnExportar.Name = "btnExportar";
            this.btnExportar.Size = new System.Drawing.Size(138, 41);
            this.btnExportar.TabIndex = 0;
            this.btnExportar.Text = "Exportar";
            this.btnExportar.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(1166, 295);
            this.dataGridView1.TabIndex = 0;
            // 
            // FormModuloSQLSERVER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 683);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormModuloSQLSERVER";
            this.Text = "Módulo SQL SERVER";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControlScriptSQL.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Label lbDescritivoModulo;
        private RichTextBox richTextBoxDescricaoModulo;
        private TabControl tabControlScriptSQL;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView dataGridView1;
        private RichTextBox richTextBox2;
        private Panel panel2;
        private Button btnExecutarComando;
        private Panel panel3;
        private Button btnExportar;
    }
}