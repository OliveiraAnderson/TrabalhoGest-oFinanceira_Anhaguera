﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuditA
{
    public class CONN
    {
        private static string server = @"localhost";
        private static string database = "DB_BASE";
        private static string users = "studio_fiscal";
        private static string password = "sf@2012!@#$";


        public static string strCONN
        {

            get {return "Data Source=" + server + "; Integrated Security=False; Initial Catalog=" + database +
                 "; User ID =" + users + "; Password=" + password;}

        }



    }
}
